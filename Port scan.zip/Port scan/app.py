from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import socket
import threading
import time

app = Flask(__name__)
CORS(app)

# Common ports database
PORT_DB = {
    20: 'FTP-DATA', 21: 'FTP', 22: 'SSH', 23: 'TELNET',
    25: 'SMTP', 53: 'DNS', 80: 'HTTP', 110: 'POP3',
    111: 'RPC', 135: 'MSRPC', 139: 'NETBIOS', 143: 'IMAP',
    443: 'HTTPS', 445: 'SMB', 993: 'IMAPS', 995: 'POP3S',
    1723: 'PPTP', 3306: 'MYSQL', 3389: 'RDP', 5432: 'POSTGRESQL',
    5900: 'VNC', 6379: 'REDIS', 8080: 'HTTP-ALT', 8443: 'HTTPS-ALT',
    27017: 'MONGODB'
}

scan_results = {}
scan_progress = {}

def scan_port(ip, port, results, total_ports):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.5)
        result = sock.connect_ex((ip, port))
        sock.close()
        
        service = PORT_DB.get(port, 'UNKNOWN')
        if result == 0:
            status = 'OPEN'
            # Try to get service banner
            try:
                banner_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                banner_sock.settimeout(0.5)
                banner_sock.connect((ip, port))
                banner_sock.send(b'\n')
                banner = banner_sock.recv(1024).decode('utf-8', errors='ignore').strip()
                if banner:
                    service = banner[:50]  # Truncate long banners
                banner_sock.close()
            except:
                pass
        elif result == 111:
            status = 'FILTERED'
        else:
            status = 'CLOSED'
        
        results.append({
            'port': port,
            'status': status,
            'service': service,
            'banner': service if status == 'OPEN' else ''
        })
    except:
        results.append({'port': port, 'status': 'ERROR', 'service': 'UNKNOWN'})
    
    # Update progress
    if 'progress' in scan_progress:
        scan_progress['progress'] += 1
        scan_progress['percentage'] = int((scan_progress['progress'] / total_ports) * 100)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/scan', methods=['POST'])
def start_scan():
    data = request.get_json()
    target = data.get('target', '')
    ports = data.get('ports', '1-1000')
    
    # Parse port range
    try:
        if '-' in ports:
            start, end = map(int, ports.split('-'))
            port_list = list(range(start, min(end + 1, 65535)))
        elif ',' in ports:
            port_list = [int(p.strip()) for p in ports.split(',')]
        else:
            port_list = [int(ports)]
    except:
        return jsonify({'error': 'Invalid port range'}), 400
    
    # Validate target
    try:
        socket.gethostbyname(target)
    except:
        return jsonify({'error': 'Invalid target IP/hostname'}), 400
    
    # Initialize results
    scan_id = str(int(time.time()))
    scan_results[scan_id] = {'results': [], 'status': 'scanning', 'target': target}
    scan_progress['progress'] = 0
    scan_progress['percentage'] = 0
    
    # Start scanning in background
    def scan_thread():
        results = []
        threads = []
        total = len(port_list)
        scan_progress['progress'] = 0
        scan_progress['percentage'] = 0
        
        # Use thread pool for faster scanning
        for port in port_list:
            thread = threading.Thread(target=scan_port, args=(target, port, results, total))
            threads.append(thread)
            thread.start()
            
            # Limit concurrent threads
            if len(threads) >= 50:
                for t in threads:
                    t.join()
                threads = []
        
        # Wait for remaining threads
        for t in threads:
            t.join()
        
        scan_results[scan_id]['results'] = sorted(results, key=lambda x: x['port'])
        scan_results[scan_id]['status'] = 'complete'
    
    threading.Thread(target=scan_thread).start()
    
    return jsonify({'scan_id': scan_id, 'message': 'Scan started'})

@app.route('/api/status/<scan_id>')
def get_status(scan_id):
    if scan_id not in scan_results:
        return jsonify({'error': 'Scan not found'}), 404
    
    data = scan_results[scan_id]
    return jsonify({
        'status': data['status'],
        'target': data['target'],
        'results': data['results'] if data['status'] == 'complete' else [],
        'progress': scan_progress.get('percentage', 0)
    })

@app.route('/api/quick-scan', methods=['POST'])
def quick_scan():
    data = request.get_json()
    target = data.get('target', '')
    
    # Quick scan on common ports
    common_ports = [20, 21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 
                    445, 993, 995, 1723, 3306, 3389, 5432, 5900, 6379, 8080, 8443, 27017]
    
    try:
        socket.gethostbyname(target)
    except:
        return jsonify({'error': 'Invalid target'}), 400
    
    results = []
    for port in common_ports:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.3)
            result = sock.connect_ex((target, port))
            sock.close()
            
            service = PORT_DB.get(port, 'UNKNOWN')
            status = 'OPEN' if result == 0 else 'CLOSED'
            results.append({'port': port, 'status': status, 'service': service})
        except:
            results.append({'port': port, 'status': 'ERROR', 'service': 'UNKNOWN'})
    
    return jsonify({'target': target, 'results': sorted(results, key=lambda x: x['port'])})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8000)