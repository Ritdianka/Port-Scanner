let currentScanId = null;
let isScanning = false;
let statusCheckInterval = null;

async function startScan() {
    const target = document.getElementById('target').value.trim();
    if (!target) {
        alert('Please enter a target IP or hostname');
        return;
    }

    const portPreset = document.getElementById('portPreset').value;
    let ports = portPreset;
    if (portPreset === 'custom') {
        ports = document.getElementById('customPorts').value;
        if (!ports) {
            alert('Please enter custom ports');
            return;
        }
    }

    const scanMode = document.getElementById('scanMode').value;

    // UI updates
    document.getElementById('scanBtn').disabled = true;
    document.getElementById('scanBtn').innerHTML = '<span class="icon">⏳</span> Scanning...';
    document.getElementById('stopBtn').style.display = 'inline-block';
    isScanning = true;
    
    document.getElementById('terminalOutput').textContent += `\n> Starting scan on ${target}...`;
    document.getElementById('statusText').textContent = 'Scanning...';

    try {
        const response = await fetch('/api/scan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ target, ports, mode: scanMode })
        });

        const data = await response.json();
        if (data.error) {
            alert(data.error);
            resetUI();
            return;
        }

        currentScanId = data.scan_id;
        checkScanStatus(currentScanId);

    } catch (error) {
        alert('Error connecting to server');
        resetUI();
    }
}

async function checkScanStatus(scanId) {
    if (statusCheckInterval) clearInterval(statusCheckInterval);

    statusCheckInterval = setInterval(async () => {
        try {
            const response = await fetch(`/api/status/${scanId}`);
            const data = await response.json();

            if (data.status === 'complete') {
                clearInterval(statusCheckInterval);
                displayResults(data.results);
                resetUI();
                document.getElementById('terminalOutput').textContent += '\n> Scan complete! ✅';
                document.getElementById('statusText').textContent = 'Complete';
                return;
            }

            // Update progress
            const progress = data.progress || 0;
            document.getElementById('progressFill').style.width = progress + '%';
            document.getElementById('progressText').textContent = progress + '%';
            document.getElementById('statusText').textContent = `Scanning... ${progress}%`;

        } catch (error) {
            clearInterval(statusCheckInterval);
            resetUI();
        }
    }, 500);
}

function displayResults(results) {
    const tbody = document.getElementById('resultsBody');
    const count = document.getElementById('resultCount');
    
    if (!results || results.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="empty-state"><span class="icon">📭</span><p>No open ports found</p></td></tr>`;
        count.textContent = '0 ports found';
        return;
    }

    // Update stats
    const openCount = results.filter(r => r.status === 'OPEN').length;
    const closedCount = results.filter(r => r.status === 'CLOSED').length;
    const filteredCount = results.filter(r => r.status === 'FILTERED').length;
    
    document.getElementById('openCount').textContent = openCount;
    document.getElementById('closedCount').textContent = closedCount;
    document.getElementById('filteredCount').textContent = filteredCount;
    document.getElementById('totalCount').textContent = results.length;
    count.textContent = `${results.length} ports found`;

    // Build table
    tbody.innerHTML = results.map(r => {
        const statusClass = `status-${r.status.toLowerCase()}`;
        return `<tr>
            <td>${r.port}</td>
            <td><span class="${statusClass}">${r.status}</span></td>
            <td>${r.service || 'UNKNOWN'}</td>
            <td>${r.banner || '-'}</td>
        </tr>`;
    }).join('');

    // Terminal output
    const term = document.getElementById('terminalOutput');
    term.textContent += '\n\n📊 Scan Results:';
    results.forEach(r => {
        const icon = r.status === 'OPEN' ? '🟢' : r.status === 'FILTERED' ? '🟡' : '🔴';
        term.textContent += `\n  ${icon} Port ${r.port}: ${r.status} (${r.service || 'UNKNOWN'})`;
    });
}

function stopScan() {
    if (statusCheckInterval) clearInterval(statusCheckInterval);
    resetUI();
    document.getElementById('terminalOutput').textContent += '\n> Scan stopped by user ⚠️';
    document.getElementById('statusText').textContent = 'Stopped';
}

function clearResults() {
    document.getElementById('resultsBody').innerHTML = `<tr><td colspan="4" class="empty-state"><span class="icon">🔍</span><p>Enter a target and click "Start Scan"</p></td></tr>`;
    document.getElementById('openCount').textContent = '0';
    document.getElementById('closedCount').textContent = '0';
    document.getElementById('filteredCount').textContent = '0';
    document.getElementById('totalCount').textContent = '0';
    document.getElementById('resultCount').textContent = '0 ports found';
    document.getElementById('progressFill').style.width = '0%';
    document.getElementById('progressText').textContent = '0%';
    document.getElementById('terminalOutput').textContent = '> CyberScan v2.0 ready\n> Enter target to begin scan';
    document.getElementById('statusText').textContent = 'Ready';
}

function exportResults() {
    const rows = document.querySelectorAll('#resultsBody tr');
    if (rows.length === 0 || rows[0].querySelector('.empty-state')) {
        alert('No results to export');
        return;
    }

    let csv = 'Port,Status,Service,Banner\n';
    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length === 4) {
            const port = cells[0].textContent;
            const status = cells[1].textContent.trim();
            const service = cells[2].textContent;
            const banner = cells[3].textContent;
            csv += `${port},${status},${service},"${banner}"\n`;
        }
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `scan_results_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
}

function resetUI() {
    document.getElementById('scanBtn').disabled = false;
    document.getElementById('scanBtn').innerHTML = '<span class="icon">🚀</span> Start Scan';
    document.getElementById('stopBtn').style.display = 'none';
    isScanning = false;
    if (statusCheckInterval) clearInterval(statusCheckInterval);
}

// Custom port input toggle
document.getElementById('portPreset').addEventListener('change', function() {
    const customInput = document.getElementById('customPorts');
    if (this.value === 'custom') {
        customInput.style.display = 'block';
    } else {
        customInput.style.display = 'none';
    }
});

// Quick scan with Enter key
document.getElementById('target').addEventListener('keypress', function(e) {
    if (e.key === 'Enter' && !document.getElementById('scanBtn').disabled) {
        startScan();
    }
});