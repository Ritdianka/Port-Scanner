# 🛡️ CyberScan Pro - Port Scanner Simulator

Network reconnaissance tool untuk pembelajaran cybersecurity.

## ⚠️ PENTING — JANGAN BUKA `index.html` LANGSUNG

Project ini **BUKAN** website statis biasa. `index.html` pakai syntax Flask
(`{{ url_for(...) }}`) yang cuma diproses kalau dijalankan lewat **Flask
(app.py)**.

❌ **JANGAN** buka file dengan cara ini:
- Double klik `index.html`
- Buka lewat ekstensi "Live Server" di VS Code (URL `127.0.0.1:5500/...`)

Kalau dibuka dengan cara di atas, CSS tidak akan muncul dan fitur scan
tidak akan berfungsi sama sekali, karena backend Python-nya belum jalan.

✅ **HARUS** dijalankan seperti ini:

```bash
cd cyberscan
pip install flask flask-cors
python app.py
```

Lalu buka browser ke:

```
http://127.0.0.1:5000
```

(perhatikan portnya **5000**, bukan 5500)

## 📁 Struktur Folder

```
cyberscan/
├── app.py               <-- jalankan file ini dengan `python app.py`
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── script.js
```

## ✨ Fitur
- Port scanning dengan UI modern
- Mode scan cepat dan normal
- Deteksi service dan banner grabbing
- Export hasil ke CSV
- Real-time progress tracking
